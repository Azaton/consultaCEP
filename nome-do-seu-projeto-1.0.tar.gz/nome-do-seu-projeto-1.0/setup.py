from setuptools import setup

setup(
    name='nome-do-seu-projeto',
    version='1.0',
    packages=[''],
    include_package_data=True,
    install_requires=[
        'flask',
        'requests',
    ],
)